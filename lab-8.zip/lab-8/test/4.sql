.eqp on

select count(*) from lineitem where l_shipdate < l_commitdate;
